package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Random;

/**
 * PARTE 2 - La MISMA ruta, ahora CON librerías (java.util).
 *
 * java.util no trae lista circular. Igual que en clase, le damos comportamiento
 * circular a un LinkedList mediante ROTACIÓN. La regla del juego:
 *
 *      cola.getFirst()  →  la parada que es la parada actual ahora
 *
 *      siguiente  = el primero pasa al final   (removeFirst + addLast)
 *      anterior   = el último pasa al inicio   (removeLast  + addFirst)
 *      saltar(n)  = Collections.rotate(cola, -n)
 *
 * El "círculo" es lógico: internamente el último nodo sigue apuntando a null.
 *
 * Estudiante: complete los TODO y ejecute:  mvn test -Dtest=RutaCircularLibTest
 * Observe: son las MISMAS pruebas de la Parte 1. Si pasan, su librería se
 * comporta igual que su lista manual.
 */
public class RutaCircularLib implements RutaCircular {

    private final LinkedList<Parada> cola = new LinkedList<>();

    @Override
    public void agregar(Parada c) {
        // TODO L1: agregue la parada AL FINAL de 'cola' (addLast).
        cola.addLast(c);
    }

    @Override
    public Parada actual() {
        // TODO L2: devuelva el primero SIN sacarlo. peekFirst() devuelve null si está vacía
        //         (getFirst() lanzaría excepción: ¿cuál conviene aquí y por qué?)
        if (cola.isEmpty()) {
            return null;
        } else {
            Parada paradaActual = cola.peekFirst();
            return paradaActual;
        }
    }

    @Override
    public Parada siguiente() {
        // TODO L3: si 'cola' está vacía devuelva null.
        //          Si no: saque el primero (removeFirst) y agréguelo al final (addLast),
        //          luego devuelva el nuevo primero.
        if (cola.isEmpty()) {
            return null;
        }
        
        Parada paradaMovida = cola.removeFirst();
        cola.addLast(paradaMovida);
        
        Parada nuevoPrimero = cola.peekFirst();
        return nuevoPrimero;
    }

    @Override
    public Parada anterior() {
        // TODO L4: lo contrario de siguiente(): removeLast + addFirst.
        if (cola.isEmpty()) {
            return null;
        }
        
        Parada paradaMovida = cola.removeLast();
        cola.addFirst(paradaMovida);
        
        Parada nuevoPrimero = cola.peekFirst();
        return nuevoPrimero;
    }

    @Override
    public Parada saltar(int n) {
        // TODO L5: si está vacía devuelva null.
        //          Use Collections.rotate(cola, distancia).
        //          Pregunta: para adelantar n paradas, ¿la distancia es n o -n?
        //          Pruebe con una lista [A,B,C,D] en papel.
        //          Devuelva el nuevo primero.
        if (cola.isEmpty()) {
            return null;
        }
        
        Collections.rotate(cola, -n);
        
        Parada paradaActual = cola.peekFirst();
        return paradaActual;
    }

    @Override
    public Parada eliminarActual() {
        // TODO L6: si está vacía devuelva null. Si no, elimine el primero (removeFirst)
        //          y devuelva el que quedó de primero. ¡Compare con las 15 líneas
        //          del Hito 4 de la Parte 1!
        if (cola.isEmpty()) {
            return null;
        }
        
        cola.removeFirst();
        
        if (cola.isEmpty()) {
            return null;
        }
        
        Parada paradaSiguiente = cola.peekFirst();
        return paradaSiguiente;
    }

    @Override
    public int tamanio() {
        int cantidad = cola.size();
        return cantidad;                        // YA RESUELTO
    }

    @Override
    public int tiempoTotal() {
        // TODO L7: sume los minutos con un for-each sobre 'cola'.
        //          (Opcional: hágalo con streams:  cola.stream().mapToInt(Parada::minutos).sum() )
        if (cola.isEmpty()) {
            return 0;
        }
        
        int sumaTotalMinutos = 0;
        for (Parada paradaActual : cola) {
            int minutosParada = paradaActual.minutos();
            sumaTotalMinutos = sumaTotalMinutos + minutosParada;
        }
        
        return sumaTotalMinutos;
    }

    @Override
    public List<String> nombresDesdeActual() {
        // YA RESUELTO: observe el ListIterator, es el iterador "con memoria de posición".
        List<String> nombres = new ArrayList<>();
        ListIterator<Parada> it = cola.listIterator();
        while (it.hasNext()) {
            Parada p = it.next();
            nombres.add(p.nombre());
        }
        return nombres;
    }

    // ═════════ RETOS EXTRA (solo si terminó antes de tiempo) ═════════

    /**
     * RETO EXTRA 1: salta directamente a una parada por título (ignore mayúsculas).
     * Devuelve false si no existe y no cambia nada.
     * Pista: ListIterator tiene nextIndex(); luego reutilice saltar(indice).
     */
    public boolean irA(String nombre) {
        if (cola.isEmpty()) {
            return false;
        }
        
        ListIterator<Parada> it = cola.listIterator();
        boolean encontrado = false;
        
        while (it.hasNext()) {
            Parada p = it.next();
            if (p.nombre().equalsIgnoreCase(nombre)) {
                int indice = it.previousIndex();
                saltar(indice);
                encontrado = true;
                break;
            }
        }
        
        return encontrado;
    }

    /**
     * RETO EXTRA 2: recorrido alternativo. Reordene la cola con Collections.shuffle,
     * pasando  new Random(semilla)  para que sea repetible.
     */
    public void reordenar(long semilla) {
        if (!cola.isEmpty()) {
            Random generadorAleatorio = new Random(semilla);
            Collections.shuffle(cola, generadorAleatorio);
        }
    }
}