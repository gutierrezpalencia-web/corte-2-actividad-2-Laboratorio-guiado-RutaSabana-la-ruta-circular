package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.List;

/**
 * PARTE 1 - RutaCircular circular SIN librerías (lista doblemente enlazada circular).
 *
 *           ┌────────────────────────────────────────────┐
 *           ▼                                            │
 *   primero → [A] ⇄ [B] ⇄ [C] ⇄ [D] ⇄ ... ⇄ [Z] ──────────┘
 *             ▲
 *           actual  (la parada que es la parada actual)
 *
 * Dos referencias:
 *   primero: la primera parada agregada. Como la lista es circular,
 *            el ÚLTIMO nodo siempre es  primero.anterior  (¡inserción al final en O(1)!)
 *   actual : la parada que está en servicio ahora
 *
 * Estudiante: busque los comentarios  "TODO"  y complete el código.
 * Después de cada hito ejecute:  mvn test -Dtest=RutaCircularManualTest
 */
public class RutaCircularManual implements RutaCircular {

    private Nodo primero;
    private Nodo actual;
    private int tamanio;

    // ══════════════════════ HITO 1: agregar (≈ 8 min) ══════════════════════
    @Override
    public void agregar(Parada c) {
        Nodo nuevo = new Nodo(c);

        if (primero == null) {
            // Lista vacía: el nodo se apunta a sí mismo en ambos sentidos (YA RESUELTO)
            nuevo.siguiente = nuevo;
            nuevo.anterior = nuevo;
            primero = nuevo;
            actual = nuevo;
        } else {
            Nodo ultimo = primero.anterior;   // el último está "detrás" del primero

            // TODO 1.1: enlace del nuevo hacia atrás  (el nuevo viene después de 'ultimo')
            nuevo.anterior = ultimo;

            // TODO 1.2: enlace del nuevo hacia adelante (después del último viene 'primero')
            nuevo.siguiente = primero;

            // TODO 1.3: 'ultimo' ahora debe apuntar hacia adelante al nuevo
            ultimo.siguiente = nuevo;

            // TODO 1.4: 'primero' ahora debe apuntar hacia atrás al nuevo (cierra el círculo)
            primero.anterior = nuevo;
        }
        tamanio++;
    }

    @Override
    public Parada actual() {
        if (actual == null) {
            return null;
        } else {
            return actual.dato;
        }
    }

    // ══════════════════ HITO 2: siguiente / anterior (≈ 6 min) ═════════════
    @Override
    public Parada siguiente() {
        if (actual == null) {
            return null;
        }
        
        actual = actual.siguiente;
        Parada paradaSiguiente = actual.dato;
        return paradaSiguiente;
    }

    @Override
    public Parada anterior() {
        if (actual == null) {
            return null;
        }
        
        actual = actual.anterior;
        Parada paradaAnterior = actual.dato;
        return paradaAnterior;
    }

    // ═════════════════ HITO 3: adelantar / retroceder N (≈ 6 min) ══════════
    @Override
    public Parada saltar(int n) {
        if (actual == null) {
            return null;
        }
        if (tamanio == 0) {
            return null;
        }
        
        int saltos = n % tamanio;
        
        if (saltos > 0) {
            int i = 0;
            while (i < saltos) {
                actual = actual.siguiente;
                i++;
            }
        } else if (saltos < 0) {
            int saltosNegativos = saltos * -1;
            int i = 0;
            while (i < saltosNegativos) {
                actual = actual.anterior;
                i++;
            }
        }
        
        Parada paradaActual = actual.dato;
        return paradaActual;
    }

    // ═══════════════ HITO 4: eliminar la que es la parada actual (≈ 10 min) ══════════════
    @Override
    public Parada eliminarActual() {
        if (actual == null) {
            return null;               
        }

        if (tamanio == 1) {                            
            primero = null;
            actual = null;
            tamanio = 0;
            return null;
        }

        Nodo previo = actual.anterior;                     
        Nodo proximo = actual.siguiente;

        // TODO 4.1: "puentear" el nodo: que 'previo' apunte hacia adelante a 'proximo'
        previo.siguiente = proximo;

        // TODO 4.2: y que 'proximo' apunte hacia atrás a 'previo'
        proximo.anterior = previo;

        // TODO 4.3: CUIDADO. Si la que eliminamos era 'primero'
        if (actual == primero) {
            primero = proximo;
        }

        // TODO 4.4: la siguiente parada pasa a quedar como parada actual
        actual = proximo;
        tamanio--;

        // TODO 4.5: devuelva la parada que es la parada actual ahora
        return actual.dato;
    }

    @Override
    public int tamanio() {
        return tamanio;                                
    }

    // ═════════ HITO 5: recorrer una vuelta con do-while (≈ 5 min) ══════════
    @Override
    public int tiempoTotal() {
        if (tamanio == 0) {
            return 0;
        }
        if (primero == null) {
            return 0;
        }
        
        int acumuladorMinutos = 0;
        Nodo punteroAuxiliar = primero;
        
        do {
            acumuladorMinutos = acumuladorMinutos + punteroAuxiliar.dato.minutos();
            punteroAuxiliar = punteroAuxiliar.siguiente;
        } while (punteroAuxiliar != primero);
        
        return acumuladorMinutos;
    }

    @Override
    public List<String> nombresDesdeActual() {
        List<String> listaNombres = new ArrayList<>();
        
        if (actual == null) {
            return listaNombres;
        }
        
        Nodo aux = actual;
        do {
            listaNombres.add(aux.dato.nombre());
            aux = aux.siguiente;
        } while (aux != actual);
        
        return listaNombres;
    }
}